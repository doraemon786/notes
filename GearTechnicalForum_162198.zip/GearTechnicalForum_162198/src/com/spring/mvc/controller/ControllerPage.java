package com.spring.mvc.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.spring.mvc.exception.MyException;
import com.spring.mvc.model.query_master;
import com.spring.mvc.service.query_masterservice;

@Controller
public class ControllerPage {

	@Autowired
	query_masterservice qser;

	@RequestMapping("/HomePage")
	public String showHomePage(Model model)
	{
		String view="HomePage";
		model.addAttribute("query",new query_master());
		return view;
	}
	
	@RequestMapping("/searchPage")
	public String validatesearchPage(@Valid @ModelAttribute("query") query_master query ,BindingResult bindingResult,Model model,HttpServletRequest req) throws MyException
	{
        query_master querymaster=qser.searchqueryById(query.getQuery_id());
		
		if(querymaster!=null)
		{
		String view="showData";
		List<String> list=new ArrayList<>();
		list.add("Uma");
		list.add("Rahul");
		list.add("Kavita");
		list.add("Hema");
		model.addAttribute("query",new query_master());
		ServletContext context1=req.getServletContext();
		context1.setAttribute("student",list);
		ServletContext context=req.getServletContext();
		context.setAttribute("queryData",querymaster);
		return view;
	}
		else
		{
			throw new MyException("Query Not Found, Wrong Query Id "+" "+query.getQuery_id());
		}
	}
	@RequestMapping("/queryanswer")
	public String showHomePage(@Valid@ModelAttribute("query_master") query_master qmaster,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="display";
		qser.setqueryData(qmaster);
		model.addAttribute("qmaster",new query_master());
		ServletContext context=req.getServletContext();
		context.setAttribute("message",qmaster);
		return view;
	}

}

		