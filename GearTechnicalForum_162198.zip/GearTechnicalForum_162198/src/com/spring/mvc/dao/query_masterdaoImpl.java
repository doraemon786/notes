package com.spring.mvc.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.spring.mvc.model.query_master;
@Repository
public class query_masterdaoImpl implements query_masterdao 
{
    @PersistenceContext
	private EntityManager manager;
	
    @Override
	public query_master searchqueryById(int id) 
	{
    	return manager.find(query_master.class, id);
	}

	@Override
	public void setqueryData(query_master qmaster) {
		query_master  QueryMaster=manager.find(query_master.class,qmaster.getQuery_id());
		QueryMaster.setSolutions(qmaster.getSolutions());
		QueryMaster.setSolutionBy(qmaster.getSolutionBy());
		manager.persist(QueryMaster);
		
	}
}

