package com.spring.mvc.exception;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalController 
{
	@ExceptionHandler(Exception.class)
	public String empException(Model model,Exception excp,HttpServletRequest req)
	{
		String view="error";
		ServletContext context=req.getServletContext();
		context.setAttribute("err", excp.getMessage());
		return view;
}
}
