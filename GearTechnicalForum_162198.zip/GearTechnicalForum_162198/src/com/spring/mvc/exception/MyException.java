package com.spring.mvc.exception;

public class MyException extends Exception 
{
	public MyException(String message) {
		super(message);
		
	}
}
