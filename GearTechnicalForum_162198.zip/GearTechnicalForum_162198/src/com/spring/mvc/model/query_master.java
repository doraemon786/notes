package com.spring.mvc.model;

import javax.persistence.Entity;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class query_master {
	@Override
	public String toString() {
		return "query_master [query_id=" + query_id + ", technology="
				+ technology + ", query_raised_by=" + query_raised_by
				+ ", query=" + query + ", solutions=" + solutions
				+ ", solutionBy=" + solutionBy + "]";
	}
	public query_master()
	{
		
	}
public query_master(int query_id, String technology,
			String query_raised_by, String query, String solutions,
			String solutionBy) {
		super();
		this.query_id = query_id;
		this.technology = technology;
		this.query_raised_by = query_raised_by;
		this.query = query;
		this.solutions = solutions;
		this.solutionBy = solutionBy;
	}

public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getSolutionBy() {
		return solutionBy;
	}

	public void setSolutionBy(String solutionBy) {
		this.solutionBy = solutionBy;
	}



public int getQuery_id() {
		return query_id;
	}

	public void setQuery_id(int query_id) {
		this.query_id = query_id;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQuery_raised_by() {
		return query_raised_by;
	}

	public void setQuery_raised_by(String query_raised_by) {
		this.query_raised_by = query_raised_by;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

int query_id;

@NotEmpty(message="Designation can not be empty")
String technology;

@NotEmpty(message="Designation can not be empty")
String query_raised_by;

@NotEmpty(message="Designation can not be empty")
String query;
String solutions;
String solutionBy;



}
