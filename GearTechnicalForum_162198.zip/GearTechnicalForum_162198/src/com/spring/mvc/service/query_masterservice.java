package com.spring.mvc.service;

import com.spring.mvc.model.query_master;

public interface query_masterservice 
{
	query_master searchqueryById(int id);
	void setqueryData(query_master qmaster);
}
