package com.spring.mvc.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.mvc.dao.query_masterdao;
import com.spring.mvc.model.query_master;

@Service
@Transactional
public class query_masterserviceImpl implements query_masterservice
{
	@Autowired
	  query_masterdao quedao;
	
	@Override
	public query_master searchqueryById(int id) 
	{
	return quedao.searchqueryById(id);

    }

	@Override
	public void setqueryData(query_master qmaster) 
	{
	
		quedao.setqueryData(qmaster);
	}
}
