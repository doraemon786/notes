package com.spring.querymgmt.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.spring.querymgmt.exception.myException;
import com.spring.querymgmt.model.Query_master;
import com.spring.querymgmt.service.IQueryService;

@Controller
public class Query_Controller {

	@Autowired
	IQueryService qSer;
	
	@RequestMapping("Home")
	public String showHomePage(Model model) {
		model.addAttribute("Query_master",new Query_master());
		String view="HomePage";
		return view;
	}

	
	@RequestMapping(value="/searchMyPage" ,method=RequestMethod.POST)
	public String searchById(@Valid @ModelAttribute("query") Query_master quer, BindingResult result, Model model, HttpServletRequest req) throws myException{
	
		Query_master querry= qSer.searchById(quer.getQuery_id());
		if(querry!=null) {
			model.addAttribute("query",new Query_master());
			model.addAttribute("message","Gear Technical Forum");
			model.addAttribute("message1","Answer the query");
			String view="Show_query_details";
			List<String> list=new ArrayList<>();
			list.add("Uma");
			list.add("Rahul");
			list.add("Kavita");
			list.add("Hema");
			ServletContext context=req.getServletContext();
			context.setAttribute("SMEList",list);
			ServletContext context1=req.getServletContext();
			context1.setAttribute("querry", querry);
			return view;
			
		}
		else
		{
			throw new myException("Query not found,wrong query id");
		}
		
	}
	
	@RequestMapping("/setDataPage")
	public String showHomePage(@Valid@ModelAttribute("QueryMaster") Query_master qmaster,BindingResult bindingResult,Model model,HttpServletRequest req)
	{
		String view="Success";
		qSer.setqueryData(qmaster);
		model.addAttribute("Query_master",new Query_master());
		ServletContext context=req.getServletContext();
		context.setAttribute("message",qmaster );
		return view;
	}

}
