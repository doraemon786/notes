package com.spring.querymgmt.dao;


import com.spring.querymgmt.model.Query_master;

public interface IQueryDao {

	public Query_master searchById(int id);
	
	void setqueryData(Query_master qmaster);
}
