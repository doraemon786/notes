package com.spring.querymgmt.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;


import com.spring.querymgmt.model.Query_master;

@Repository
public class QueryDaoImpl implements IQueryDao{

	@PersistenceContext
	EntityManager mgr;
	
	
	@Override
	public Query_master searchById(int id) {
		
		Query_master qmaster=mgr.find(Query_master.class, id);
		return qmaster;
		
	}
	
	@Override
	public void setqueryData(Query_master qmaster) {
		Query_master queryMas=new Query_master();
		Query_master myQueryMaster=	mgr.find(Query_master.class,qmaster.getQuery_id());
		myQueryMaster.setSolutions(qmaster.getSolutions());
		myQueryMaster.setSolution_given_by(qmaster.getSolution_given_by());
		mgr.persist(myQueryMaster);
		
	}

}
