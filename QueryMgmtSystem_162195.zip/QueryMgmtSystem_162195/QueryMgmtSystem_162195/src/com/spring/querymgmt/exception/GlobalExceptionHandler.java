package com.spring.querymgmt.exception;
import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.ModelAndView;



@ControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(Exception.class)
public ModelAndView empException(Model model,Exception excp,HttpServletRequest req)
{
	ModelAndView view =new ModelAndView("error");
	ServletContext context=req.getServletContext();
	context.setAttribute("err", excp.getMessage());
	return view;
}
}