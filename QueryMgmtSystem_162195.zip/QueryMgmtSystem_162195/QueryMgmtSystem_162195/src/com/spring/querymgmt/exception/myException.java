package com.spring.querymgmt.exception;

public class myException extends Exception{

	public myException(String message) {
		
		super(message);	
	}
}
