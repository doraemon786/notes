package com.spring.querymgmt.model;

import javax.persistence.Entity;

@Entity
public class Query_master {

	
	private int query_id;
	
	private String technology;
	
	private String query_raised_by;
	
	private String query;
	
	private String solutions;
	
	private String solution_given_by;
	
	
	//Getters and Setters
	public int getQuery_id() {
		return query_id;
	}

	public void setQuery_id(int query_id) {
		this.query_id = query_id;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQuery_raised_by() {
		return query_raised_by;
	}

	public void setQuery_raised_by(String query_raised_by) {
		this.query_raised_by = query_raised_by;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getSolutions() {
		return solutions;
	}

	public void setSolutions(String solutions) {
		this.solutions = solutions;
	}

	public String getSolution_given_by() {
		return solution_given_by;
	}

	public void setSolution_given_by(String solution_given_by) {
		this.solution_given_by = solution_given_by;
	}
	
	
	//default Constructor
	public Query_master() {
		super();
	}

	//parameterized constructor
	public Query_master(int query_id, String technology, String query_raised_by, String query, String solutions,
			String solution_given_by) {
		super();
		this.query_id = query_id;
		this.technology = technology;
		this.query_raised_by = query_raised_by;
		this.query = query;
		this.solutions = solutions;
		this.solution_given_by = solution_given_by;
	}

	//toString 
	@Override
	public String toString() {
		return "Query_master [query_id=" + query_id + ", technology=" + technology + ", query_raised_by="
				+ query_raised_by + ", query=" + query + ", solutions=" + solutions + ", solution_given_by="
				+ solution_given_by + "]";
	}
	
	
	

	
}
