package com.spring.querymgmt.service;


import com.spring.querymgmt.model.Query_master;

public interface IQueryService
{

	public Query_master searchById(int id);
	void setqueryData(Query_master qmaster);
}
