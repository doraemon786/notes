package com.spring.querymgmt.service;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.spring.querymgmt.dao.IQueryDao;
import com.spring.querymgmt.model.Query_master;

@Service
@Transactional
public class QueryServiceImpl implements IQueryService {

	@Autowired
	IQueryDao qDao;
	@Override
	public Query_master searchById(int id) {
		return qDao.searchById(id);
	}
	
	@Override
	public void setqueryData(Query_master qmaster) {
		qDao.setqueryData(qmaster);
		
	}

}
