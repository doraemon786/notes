package com.cg.csd;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


@Component
public class Department 
{
	String deptName;
	@Autowired
	List<Employee> emps;
	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	@Autowired
	public void printEmployeeDetails()
	{
		for(Employee e:emps)
		{
			System.out.println("employee id: "+e.getEmpId());
			System.out.println("employee name: "+e.getEmpName());
			System.out.println("employee departmentName: "+e.getDeptName());
		}
	}
	
}