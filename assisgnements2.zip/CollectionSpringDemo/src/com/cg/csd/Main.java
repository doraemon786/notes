package com.cg.csd;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		ApplicationContext context =new ClassPathXmlApplicationContext("config.xml");
		
		//Department d=(Department) context.getBean("dep");
		Department d1=context.getBean(Department.class);
		//d.printEmployeeDetails();
		d1.printEmployeeDetails();

	}

}
