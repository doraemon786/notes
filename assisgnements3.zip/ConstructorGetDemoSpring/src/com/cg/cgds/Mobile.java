package com.cg.cgds;

public class Mobile 
{
	String CcompanyName;
	float mobilePrice;
	String mobiletype;
	public Mobile(String ccompanyName, float mobilePrice, String mobiletype) {
		super();
		CcompanyName = ccompanyName;
		this.mobilePrice = mobilePrice;
		this.mobiletype = mobiletype;
	}
	public String getCcompanyName() {
		return CcompanyName;
	}
	public float getMobilePrice() {
		return mobilePrice;
	}
	public String getMobiletype() {
		return mobiletype;
	}
	
}
