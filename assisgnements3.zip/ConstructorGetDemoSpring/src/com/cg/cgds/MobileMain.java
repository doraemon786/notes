package com.cg.cgds;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class MobileMain {

	public static void main(String[] args) {
		XmlBeanFactory factory=new XmlBeanFactory(new ClassPathResource("config.xml"));
		Mobile m=(Mobile) factory.getBean("mybean");
		System.out.println("Mobile company name: "+m.getCcompanyName());
		System.out.println("Mobile price: "+m.getMobilePrice());
		System.out.println("Mobile type: "+m.getMobiletype());
	}

}
