package com.cg.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl 
{
	
	Connection conn=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Login user=null;
public LoginDaoImpl()
{

}
public Login getUserDetails(String unm) throws SQLException
{
	conn=DBUtil.getCon();
	System.out.println("In dao got connection" +conn);
	String sql="select * from login_tbl where USER_NAME=?";

	
		pst=conn.prepareStatement(sql);
		pst.setString(1,unm);
		rs=pst.executeQuery();
		rs.next();
		user=new Login(rs.getString(1),rs.getString(2));

	return user;
}
}
