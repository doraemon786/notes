package com.cg.Dao;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.dto.Login;
import com.cg.util.DBUtil;

public class LoginDaoImpl 
{
	
	Connection conn=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	Login user=null;
	Statement st=null;
public LoginDaoImpl()
{

}
public Login getUserDetails(String unm) throws SQLException
{
	conn=DBUtil.getCon();
	System.out.println("In dao got connection" +conn);
	String sql="select * from login_tbl where USER_NAME=?";

	
		pst=conn.prepareStatement(sql);
		pst.setString(1,unm);
		rs=pst.executeQuery();
		rs.next();
		user=new Login(rs.getString(1),rs.getString(2));

	return user;
}
public ArrayList<Login> getAllDetails() throws Exception
{
	ArrayList<Login> userList=new ArrayList<>();
	conn=DBUtil.getCon();
	st=conn.createStatement();
	rs=st.executeQuery("select * from login_tbl");
	while(rs.next())
	{
		userList.add(new Login(rs.getString(1),rs.getString(2)));
	}
	return userList;
	
}
}
