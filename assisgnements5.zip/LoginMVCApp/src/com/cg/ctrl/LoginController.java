package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Login;
import com.cg.service.LoginServiceImpl;
import com.sun.webkit.ContextMenu.ShowContext;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig config=null;
    public LoginController()
    {
        super();
    }
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
		this.config=config;
		System.out.println("Controller servlet init");
	}

	public void destroy()
	{
	System.out.println("Controller servlet destroyed");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
	doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		LoginServiceImpl logSer=new LoginServiceImpl();
		String action=request.getParameter("action");
		ServletContext ctx=config.getServletContext();
		String cn=(String)ctx.getInitParameter("compName");
		ctx.setAttribute("compNameObj",cn);
		if(action!=null)
		{
			RequestDispatcher rd=null;
			//for homepage
			if(action.equalsIgnoreCase("ShowHomePage"))
			{
				rd=request.getRequestDispatcher("Pages/Home.jsp");
				rd.forward(request,response);
			}
			//for loginpage
			if(action.equalsIgnoreCase("ShowLoginPage"))
			{
				try {
					ArrayList list1=logSer.getAllDetails();
					request.setAttribute("userlistobj",list1);
					rd=request.getRequestDispatcher("Pages/Login.jsp");
					rd.forward(request,response);

				} catch (Exception e) {
					rd=request.getRequestDispatcher("Pages/Error.jsp");
					rd.forward(request, response);
					e.printStackTrace();
				}
				rd=request.getRequestDispatcher("Pages/Login.jsp");
				rd.forward(request,response);
			}
			if(action.equalsIgnoreCase("ValidateData"))
			{
				String un=request.getParameter("txtname");
				String pwd=request.getParameter("password");
				try {
					Login user=logSer.getUserDetails(un);
					if(un.equalsIgnoreCase(user.getUserName()) && pwd.equalsIgnoreCase(user.getPassword()))
					{
						HttpSession session=request.getSession(true);
						session.setAttribute("usernameobj",un);
						rd=request.getRequestDispatcher("Pages/Success.jsp");
						rd.forward(request, response);
					}
					else
					{
						String errMsg="incorrect Password";
						request.setAttribute("MsgObj",errMsg);
						rd=request.getRequestDispatcher("LoginController?action=ShowLoginPage");
						rd.forward(request,response);
					}
				} catch (SQLException e) {
					
					e.printStackTrace();
				}
			}
		}
		else
		{
			PrintWriter out=response.getWriter();
			out.println("No Action Defined");
		}
	}

}
