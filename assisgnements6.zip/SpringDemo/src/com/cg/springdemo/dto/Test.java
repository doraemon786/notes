package com.cg.springdemo.dto;

public class Test {

	public void display()
	{
		System.out.println("Hello all");
	}
}
