package com.cg.swd;

import java.util.List;



public class Department 
{
	String deptName;
	List<Employee> emps;
	public void setEmps(List<Employee> emps) {
		this.emps = emps;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public void printEmployeeDetails()
	{
		for(Employee e:emps)
		{
			System.out.println("employee id: "+e.getEmpId());
			System.out.println("employee name: "+e.getEmpName());
			System.out.println("employee departmentName: "+e.getDeptName());
		}
	}
	
}
