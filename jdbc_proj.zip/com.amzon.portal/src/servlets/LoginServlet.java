package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import util.ConnectionManager;

@WebServlet({"/LoginServlet","/login"})
public class LoginServlet extends HttpServlet {
	
 private static Connection con;
 private static ResultSet rs;
 private static PreparedStatement ps;
 private String sql="select * from appuser where username=? and password=?";
 private RequestDispatcher rd;
    public LoginServlet() {
      super();
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String uname= request.getParameter("username");
		String pwd= request.getParameter("password");
		
		con=ConnectionManager.getConnection();
		try {
			ps=con.prepareStatement(sql);
			ps.setString(1, uname);
			ps.setString(2, pwd);
		rs=ps.executeQuery();
		
		if(rs.next())
		{
		request.setAttribute("username", uname);
		rd=	request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
		}
		
		else{
			rd=request.getRequestDispatcher("index.jsp");
			rd.forward(request, response);
		}
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	
		
		
		
	/*	response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h2>Welcome "+uname+"</h2>");
		*/
	}
	

	

}
